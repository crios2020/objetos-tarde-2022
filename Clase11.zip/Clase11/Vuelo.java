public class Vuelo {
    private String nombre;
    private int cantidadPasajes=5;

    public Vuelo() {
    }

    public Vuelo(String nombre, int cantidadPasajes) {
        this.nombre = nombre;
        this.cantidadPasajes = cantidadPasajes;
    }

    public synchronized void venderPasajes(int cantidadPasajesPedidos) 
            throws NoHayMasPasajesException{
        if(cantidadPasajesPedidos>=cantidadPasajes) 
            throw new NoHayMasPasajesException(nombre, cantidadPasajes, cantidadPasajesPedidos);
        cantidadPasajes-=cantidadPasajesPedidos;
    }

    @Override
    public String toString() {
        return "Vuelo [cantidadPasajes=" + cantidadPasajes + ", nombre=" + nombre + "]";
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCantidadPasajes() {
        return cantidadPasajes;
    }

    public void setCantidadPasajes(int cantidadPasajes) {
        this.cantidadPasajes = cantidadPasajes;
    }
    
}
