import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public class Clase11{
    public static void main(String[] args){
        try {
            //GeneradorExceptions.generar();
            //GeneradorExceptions.generar(true);
            //GeneradorExceptions.generar("38x");
            //GeneradorExceptions.generar(null, 2);
            GeneradorExceptions.generar("hola", 38);
            System.out.println("Esta linea no se ejecuta!!!");
        } catch (Exception e) {
            System.out.println(e);
        }

        //UncheckedException
        //GeneradorExceptions.generar("hola", 39);

        //CheckedException
        //FileReader in=new FileReader("texto.txt");

        //Captura Personalizada de Exceptions
        try {
            //GeneradorExceptions.generar();
            //GeneradorExceptions.generar(true);
            //GeneradorExceptions.generar("38v");
            //GeneradorExceptions.generar(null, 16);
            //GeneradorExceptions.generar("hola", 26);
            FileReader in=new FileReader("texto.txt");
        } catch (ArithmeticException e)             { System.out.println("División / o");
        //} catch (ArrayIndexOutOfBoundsException e)  { System.out.println("Indice fuera de rango!");
        } catch (NumberFormatException e)           { System.out.println("Formato de número incorrecto!");
        } catch (NullPointerException e)            { System.out.println("Puntero Nulo!");
        //} catch (StringIndexOutOfBoundsException e) { System.out.println("Indice Fuera de Rango"); 
        //} catch (ArrayIndexOutOfBoundsException | StringIndexOutOfBoundsException e) { System.out.println("Indice Fuera de Rango");
        } catch (IndexOutOfBoundsException e)       { System.out.println("Indice fuera de rango!");
        } catch (FileNotFoundException e)           { System.out.println("Archivo no encontrado!");
        } catch (IOException e)                     { System.out.println("Problemas al leer un archivo");
        } catch (Exception e)                       { System.out.println("Ocurrio un error no esperado!!"); }

        try {
            Class.forName("java.lang.String").getConstructor().newInstance();
        } catch (InstantiationException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IllegalAccessException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (NoSuchMethodException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SecurityException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        //Como usar Exceptions para validar reglas de negocio
        Vuelo v1=new Vuelo("AER1234",100);
        Vuelo v2=new Vuelo("LAT1111",100);

        try {
            v1.venderPasajes(50);
            v2.venderPasajes(10);
            v1.venderPasajes(40);
            v2.venderPasajes(30);
            v1.venderPasajes(30);           //Lanza una Exception
            v2.venderPasajes(10);           //Esta venta no realiza                        
        } catch (NoHayMasPasajesException e) {
            System.out.println(e);
        }

        //sin try with resources
        //No hacer esto!!!!
        // FileReader lector=null;
        // try {
        //     lector=new FileReader("texto");
        //     System.out.println(lector.read());
        //     lector.close();
        // } catch (Exception e) {
        //     System.out.println(e);
        //     if(lector!=null){
        //         try{
        //             lector.close();
        //         }catch(Exception ex){
        //             System.out.println(ex);
        //         }
        //     }
        // } 

        //try with resources JDK 7 o sup
        try (FileReader lector=new FileReader("texto.txt")){
            System.out.println(lector.read());
        } catch (Exception e) {
            System.out.println(e);
        }

        //Api Reflect
        System.out.println(v1.getClass().getName());

        try {
            Object o=Class.forName("Vuelo")
                .getConstructor(String.class,int.class)
                .newInstance("vueloX",100);
            System.out.println(o);
            System.out.println(o.getClass().getName());
            Field[] campos=o.getClass().getDeclaredFields();    //atributos de la clase
            for(int a=0; a<campos.length; a++){
                System.out.println(campos[a]);
            }
            campos=o.getClass().getFields();                    //atributos heredados
            for(int a=0; a<campos.length; a++){
                System.out.println(campos[a]);
            }

            Method[] metodos=o.getClass().getDeclaredMethods(); //métodos de clase
            for(int a=0; a<metodos.length; a++){
                System.out.println(metodos[a]);
            }

            metodos=o.getClass().getMethods();                  //métodos heredados
            for(int a=0; a<metodos.length; a++){
                System.out.println(metodos[a]);
            }

            Constructor[] constructores=o.getClass().getDeclaredConstructors();
            for(int a=0; a<constructores.length; a++){
                System.out.println(constructores[a]);
            }
            
            o
                .getClass()
                .getMethod("setNombre", String.class)
                .invoke(o, "spaceX");
  
            System.out.println(o);
        } catch (Exception e) {
            System.out.println(e);
        }


    }
}