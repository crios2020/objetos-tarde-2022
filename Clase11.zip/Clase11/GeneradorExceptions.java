public class GeneradorExceptions {
    
    public static void generar(){
        int[] vector=new int[5];
        vector[10]=20;
        //ArrayIndexOutOfBoundsException
    }

    public static void generar(boolean x){
        if(x) System.out.println(10/0);
        //ArithmeticException
    }

    public static void generar(String nro){     //"26x"
        int n=Integer.parseInt(nro);
        //NumberFormatException
    }

    public static void generar(String text, int index){     //"hola" , 10
        //if(text==null || index>=text.length())  return;
        System.out.println(text.charAt(index));
        //NullPointerException - StringIndexOutOfBoundsException
    }
}
