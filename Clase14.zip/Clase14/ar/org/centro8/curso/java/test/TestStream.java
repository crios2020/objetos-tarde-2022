package ar.org.centro8.curso.java.test;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import ar.org.centro8.curso.java.entities.Persona;

public class TestStream {
    public static void main(String[] args) {
        List<Persona>list=new ArrayList();
        list.add(new Persona("Laura","Perez",35));
        list.add(new Persona("Juan","Perez",51));
        list.add(new Persona("Jose","Torres",33));
        list.add(new Persona("Juan","Roque",35));
        list.add(new Persona("Juana","Molina",35));
        list.add(new Persona("Juanita","Lima",35));
        list.add(new Persona("Carlos","Rios",49));
        list.add(new Persona("Omar","Soto",35));
        list.add(new Persona("Armando","Bancos",35));
        list.add(new Persona("Marta","Moreira",35));
        list.add(new Persona("Beatriz","Llave",35));
        list.add(new Persona("","",35));
        list.add(new Persona("","",35));
        list.add(new Persona("","",35));


        // for(Persona p: list){
        //     if(p.getNombre().equalsIgnoreCase("Juan")){
        //         System.out.println(p);
        //     }
        // }
        //Api Stream
        // select * from personas where nombre='Juan';
        // list
        //    .stream()
        //    .filter(p->p.getNombre().equalsIgnoreCase("Juan"))
        //    .forEach(System.out::println);

        //select * from personas where nombre like 'Juan%';
        // list
        //     .stream()
        //     .filter(p->p.getNombre().startsWith("Juan"))
        //     .forEach(System.out::println);
        
        //select * from personas where nombre like '%a';
        // list
        //     .stream()
        //     .filter(p->p.getNombre().endsWith("a"))
        //     .forEach(System.out::println);

        //select * from personas where nombre like("%ar%")
        // list
        //     .stream()
        //     .filter(p->p.getNombre().toLowerCase().contains("ar"))
        //     .forEach(System.out::println);

        // select * from personas where >40
        // list
        //     .stream()
        //     .filter(p->p.getEdad()>40)
        //     .forEach(System.out::println);

        // select * from personas where nombre="juan" and apellido like '%ez'
        // list
        //     .stream()
        //     .filter(p->p.getNombre().equalsIgnoreCase("juan")
        //             && p.getApellido().toLowerCase().endsWith("ez"))
        //     .forEach(System.out::println);

        // list
        //     .stream()
        //     .filter(p->p.getNombre().equalsIgnoreCase("juan"))
        //     .filter(p->p.getApellido().toLowerCase().endsWith("ez"))
        //     .forEach(System.out::println);

        // select * from personas where nombre="Juan" or apellido like '%ez'
        // list
        //     .stream()
        //     .filter(p->p.getNombre().equalsIgnoreCase("juan")
        //             || p.getApellido().toLowerCase().endsWith("ez"))
        //     .forEach(System.out::println);

        // select * from personas where edad between 30 and 40
        // list
        //     .stream()
        //     .filter(p->p.getEdad()>=30)
        //     .filter(p->p.getEdad()<=40)
        //     .forEach(System.out::println);
        // list
        //     .stream()
        //     .filter(p->p.getEdad()>=30 && p.getEdad()<=40)
        //     .forEach(System.out::println);

        // select max(edad) from clientes;
        int edadMax=list
            .stream()
            .max(Comparator.comparingInt(Persona::getEdad))
            .get()
            .getEdad();
        System.out.println(edadMax);

        // select min(edad) from clientes;
        int edadMin=list
            .stream()
            .min(Comparator.comparingInt(Persona::getEdad))
            .get()
            .getEdad();
        System.out.println(edadMin);

        // select * from personas where edad=(select max(edad) from personas);
        // list
        //     .stream()
        //     .filter(p->p.getEdad()==edadMax)
        //     .forEach(System.out::println);


        //No hacer esto
        // System.out.println(list
        //             .stream()
        //             .max(Comparator.comparingInt(Persona::getEdad))
        //             .get());

        //select * from personas order by nombre
        // list
        //     .stream()
        //     .sorted(Comparator.comparing(Persona::getNombre))
        //     .forEach(System.out::println);

        //Orden Natural
        // list
        //     .stream()
        //     .sorted()
        //     .forEach(System.out::println);

        //select * from personas order by nombre desc
        // list
        //     .stream()
        //     .sorted(Comparator.comparing(Persona::getNombre).reversed())
        //     .forEach(System.out::println);

        //select * from personas order by apellido, nombre desc
        list
            .stream()
            .sorted(Comparator.comparing(Persona::getApellido)
                    .thenComparing(Persona::getNombre).reversed()
            ).forEach(System.out::println);

        

    }
}
