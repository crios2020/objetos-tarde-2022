package ar.org.centro8.curso.java.test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import java.util.Vector;

import ar.org.centro8.curso.java.entities.Auto;

public class TestCollections {
    public static void main(String[] args) {
        
        //Arrays - Vectores
        Auto[] autos=new Auto[4];
        autos[0]=new Auto("Ford","Ka","Negro");
        autos[1]=new Auto("Fiat","Idea","Rojo");
        autos[2]=new Auto("Citroen","C4","Bordo");
        autos[3]=new Auto("VW","Gol","Blanco");
        
        //recorrido por indices
        //for(int a=0;a<autos.length;a++){
        //    System.out.println(autos[a]);
        //}

        //recorrido usando forEach JDK 5
        for(Auto auto : autos) System.out.println(auto);

        //Inteface List
        List lista1;
        
        //Implementación ArrayList
        lista1=new ArrayList();

        //Implementación LinkedList
        //lista1=new LinkedList();

        //Implementación Vector
        //lista1=new Vector();

        lista1.add(new Auto("Peugeot","208","Negro"));      //0
        lista1.add(new Auto("Renault","Fluence","Verde"));  //1
        lista1.add("Hola");                                                   //2
        lista1.add("Chau");                                                   //3
        lista1.add(22);                                                       //4
        lista1.add(3, "JAVA");
        lista1.remove(4);
        //lista1.add(10,"Centro 8");

        //Recorrido con indices
        System.out.println("*******************************************");
        //for(int a=0; a<lista1.size(); a++){
        //    System.out.println(lista1.get(a));
        //}

        //Recorrido foreach
        //for(Object o: lista1) System.out.println(o);

        //Método .forEach() java 8 o superior
        //lista1.forEach(o->System.out.println(o));
        //lista1.forEach(o->{
        //    System.out.println(o);
        //});
        //lista1.forEach(System.out::println);

        //Uso de Generics<>     JDK 5 o sup
        List<Auto> lista2 = new ArrayList();
        lista2.add(new Auto("Chevrolet", "Corsa", "Rojo"));
        
        Auto auto1=(Auto)lista1.get(0);
        Auto auto2=lista2.get(0);

        //Copiar los autos del vector autos a lista1;
        //for(Auto a:autos) lista1.add(a);
        lista1.addAll(List.of(autos));

        System.out.println("****************************************");
        lista1.forEach(System.out::println);

        //Copiar los autos de lista1 a lista2
        lista1.forEach(o->{
            if(o instanceof Auto) lista2.add((Auto)o);
        });
        System.out.println("****************************************");
        lista2.forEach(System.out::println);

        //Interface SET - representa una lista sin indices y sin duplicados
        Set<String>set;

        //Implementación HashSet:   Es la más veloz, pero no garantiza el
        //                          orden de los elementos
        //set=new HashSet();

        //Implementación LinkedHashSet: Almacena elementos en una lista 
        //          enlazada por orden de ingreso.
        //set=new LinkedHashSet();

        //Implementación TreeSet:   Almacena elementos en un arbol, por 
        //          orden natural.
        set=new TreeSet();

        set.add("Lunes");
        set.add("Martes");
        set.add("Miércoles");
        set.add("Jueves");
        set.add("Viernes");
        set.add("Sábado");
        set.add("Domingo");
        set.add("Lunes");
        set.add("Lunes");
        set.add("Martes");
        set.add("Martes");
        set.add("Jueves");
        set.forEach(System.out::println);

        //Set de autos
        Set<Auto>setAutos;

        //setAutos=new LinkedHashSet();
        //setAutos=new HashSet();
        setAutos=new TreeSet();
        setAutos.add(new Auto("Chevrolet","Aveo","Gris"));
        setAutos.add(new Auto("Chevrolet","Aveo","Blanco"));

        setAutos.addAll(lista2);
        setAutos.add(new Auto("Chevrolet","Corsa","Rojo"));
        System.out.println("*****************************************");
        //setAutos.forEach(System.out::println);
        setAutos.forEach(auto->System.out.println(auto+" "+auto.hashCode()));



        //TODO Pilas Colas

        //TODO Maps

        //TODO Api STREAM
        


        
        


    }
}
