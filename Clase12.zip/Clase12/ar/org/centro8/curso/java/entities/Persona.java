package ar.org.centro8.curso.java.entities;

import java.text.DecimalFormat;

public class Persona implements Comparable<Persona>{
    private String nombre;
    private String apellido;
    private int edad;
    
    public Persona(String nombre, String apellido, int edad) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
    }
    
    @Override
    public int compareTo(Persona para) {
        if(para==null) return 1;
        //String thisPersona = this.getNombre()+","+this.getApellido()+","+this.getEdad();
        //String paraPersona = para.getNombre()+","+para.getApellido()+","+para.getEdad();

        //Ana,Garcia,12;
        //Ana,Garcia,9;


        //Ana,Garcia,009;
        //Ana,Garcia,012;

        DecimalFormat df=new DecimalFormat("000");

        String thisPersona = this.getNombre()+","+this.getApellido()+","+df.format(this.getEdad());
        String paraPersona = para.getNombre()+","+para.getApellido()+","+df.format(para.getEdad());

        return thisPersona.compareTo(paraPersona);
    }

    @Override
    public String toString() {
        return "Persona [apellido=" + apellido + ", edad=" + edad + ", nombre=" + nombre + "]";
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

}
