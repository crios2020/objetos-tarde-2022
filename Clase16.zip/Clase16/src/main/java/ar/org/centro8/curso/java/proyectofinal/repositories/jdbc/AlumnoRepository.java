package ar.org.centro8.curso.java.proyectofinal.repositories.jdbc;

import java.sql.Connection;

public class AlumnoRepository {
    private Connection conn;

    public AlumnoRepository(Connection conn) {
        this.conn = conn;
    }

    
}
