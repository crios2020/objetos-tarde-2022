package ar.org.centro8.curso.java.proyectofinal.repositories.jdbc;

import java.sql.Connection;
import java.util.List;

import ar.org.centro8.curso.java.proyectofinal.entities.Curso;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_CursoRepository;

public class CursoRepository implements I_CursoRepository{
    private Connection conn;

    public CursoRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public List<Curso> getAll() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void remove(Curso curso) {
        // TODO Auto-generated method stub
        
    }

    @Override
    public void save(Curso curso) {
        
        
    }

    @Override
    public void update(Curso curso) {
        // TODO Auto-generated method stub
        
    }
    
}
