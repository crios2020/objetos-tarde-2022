package ar.org.centro8.curso.java.test;

public class Clase04{
    public static void main(String[] args) {
        System.out.println("Hola Mundo!");
    }
}