package ar.org.centro8.curso.java.entities;

public class Cuenta {
    int nro;
    String moneda;
    double saldo;
    
    public Cuenta(int nro, String moneda) {
        this.nro = nro;
        this.moneda = moneda;
    }

    

}
