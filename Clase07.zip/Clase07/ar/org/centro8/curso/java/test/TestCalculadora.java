package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.utils.Calculadora;
import ar.org.centro8.curso.java.utils.ColoresAnsi;

public class TestCalculadora {

    private static final Calculadora calculadora=new Calculadora();
    public static void main(String[] args) {
        
        sumar();

        restar();

        multiplicar();

        dividir();

    }

    private static void dividir() {
        separador("dividir");
        double resultado;
        //dividir 0/0=0
        resultado=calculadora.dividir(0, (int)0);
        if(true)System.out.println(ColoresAnsi.ANSI_GREEN+"OK \t- /0"+ColoresAnsi.ANSI_RESET);
        
        //dividir 0/(-2)=0
        resultado=calculadora.dividir(0, -2);
        if(resultado==0)System.out.println(ColoresAnsi.ANSI_GREEN+"OK \t- 0/(-2)=0"+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error \t- 0/(-2)=0"+ColoresAnsi.ANSI_RESET);
        
        //dividir 35/(-70)=-0.5
        resultado=calculadora.dividir(35, -70);
        if(resultado==-0.5)System.out.println(ColoresAnsi.ANSI_GREEN+"OK \t- 35/(-70)=-0.5"+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error \t- 35/(-70)=-0.5"+ColoresAnsi.ANSI_RESET);
        

        //dividir 10 / (-10)=-1
        resultado=calculadora.dividir(10, -10);
        if(resultado==-1)System.out.println(ColoresAnsi.ANSI_GREEN+"OK \t- 10 / (-10)=-1"+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error \t- 110 / (-10)=-1"+ColoresAnsi.ANSI_RESET);
        

        //dividir -10 / (-10)=1
        resultado=calculadora.dividir(-10, -10);
        if(resultado==1)System.out.println(ColoresAnsi.ANSI_GREEN+"OK \t- -10 / (-10)=1"+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error \t- -10 / (-10)=1"+ColoresAnsi.ANSI_RESET);
 
    }

    private static void multiplicar() {
        separador("multiplicar");

        double resultado;
        
        //multiplicar 0*0=0
        resultado=calculadora.multiplicar(0, 0);
        if(resultado==0)System.out.println(ColoresAnsi.ANSI_GREEN+"OK \t- 0*0=0"+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error \t- 0*0=0"+ColoresAnsi.ANSI_RESET);
        
        //multiplicar 0*(-2)=0
        resultado=calculadora.multiplicar(0, -2);
        if(resultado==0)System.out.println(ColoresAnsi.ANSI_GREEN+"OK \t- 0*(-2)=0"+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error \t- 0*(-2)=0"+ColoresAnsi.ANSI_RESET);
        
        //multiplicar 33*-72=-2376
        resultado=calculadora.multiplicar(33, -72);
        if(resultado==-2376)System.out.println(ColoresAnsi.ANSI_GREEN+"OK \t- 33*-72=-2376"+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error \t- 33*-72=-2376"+ColoresAnsi.ANSI_RESET);
        

        //multiplicar 10 * (-10)=-100
        resultado=calculadora.multiplicar(10, -10);
        if(resultado==-100)System.out.println(ColoresAnsi.ANSI_GREEN+"OK \t- 10 * (-10)=-100"+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error \t- 10 * (-10)=-100"+ColoresAnsi.ANSI_RESET);
        

        //multiplicar -10 * (-10)=100
        resultado=calculadora.multiplicar(-10, -10);
        if(resultado==100)System.out.println(ColoresAnsi.ANSI_GREEN+"OK \t- -10 * (-10)=100"+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error \t- -10 * (-10)=100"+ColoresAnsi.ANSI_RESET);
        

        //multiplicar -200000000000000000. - -200000000000000000.       17 veces 0
        resultado=calculadora.multiplicar(200000000000000000., -200000000000000000.);
        if(true)System.out.println(ColoresAnsi.ANSI_GREEN+"OK \t- overflow"+ColoresAnsi.ANSI_RESET);

    }

    private static void restar() {
        separador("restar");

        double resultado;
        
        //restar 0-0=0
        resultado=calculadora.restar(0, 0);
        if(resultado==0)System.out.println(ColoresAnsi.ANSI_GREEN+"OK \t- 0+0=0"+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error \t- 0+0=0"+ColoresAnsi.ANSI_RESET);
        
        //restar 2-2=-0
        resultado=calculadora.restar(2, 2);
        if(resultado==0)System.out.println(ColoresAnsi.ANSI_GREEN+"OK \t- 2-2=0"+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error \t- 2-2=0"+ColoresAnsi.ANSI_RESET);
        
        //restar 33-72=-39
        resultado=calculadora.restar(33, 72);
        if(resultado==-39)System.out.println(ColoresAnsi.ANSI_GREEN+"OK \t- 33+72=105"+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error \t- 33+72=105"+ColoresAnsi.ANSI_RESET);
        

        //restar 10 - (-10)=20
        resultado=calculadora.restar(10, -10);
        if(resultado==20)System.out.println(ColoresAnsi.ANSI_GREEN+"OK \t- 10-(-10)=20"+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error \t- 10-(-10)=20"+ColoresAnsi.ANSI_RESET);
        

        //restar -10 - (-10)=0
        resultado=calculadora.restar(-10, -10);
        if(resultado==0)System.out.println(ColoresAnsi.ANSI_GREEN+"OK \t- -10-(-10)=0"+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error \t- -10-(-10)=0"+ColoresAnsi.ANSI_RESET);
        

        //restar -200000000000000000. - -200000000000000000.       17 veces 0
        resultado=calculadora.restar(-200000000000000000., -200000000000000000.);
        if(resultado==0)System.out.println(ColoresAnsi.ANSI_GREEN+"OK \t- 200000000000000000.-200000000000000000.=0."+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error \t- 200000000000000000.-200000000000000000.=0."+ColoresAnsi.ANSI_RESET);
        

    }

    private static void sumar() {
        separador("sumar");
        double resultado;
        
        //sumar 0+0=0
        resultado=calculadora.sumar(0, 0);
        if(resultado==0)System.out.println(ColoresAnsi.ANSI_GREEN+"OK \t- 0+0=0"+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error \t- 0+0=0"+ColoresAnsi.ANSI_RESET);
        
        //sumar 2+2=4
        resultado=calculadora.sumar(2, 2);
        if(resultado==4)System.out.println(ColoresAnsi.ANSI_GREEN+"OK \t- 2+2=4"+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error \t- 2+2=4"+ColoresAnsi.ANSI_RESET);
        
        //sumar 33+72=105
        resultado=calculadora.sumar(33, 72);
        if(resultado==105)System.out.println(ColoresAnsi.ANSI_GREEN+"OK \t- 33+72=105"+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error \t- 33+72=105"+ColoresAnsi.ANSI_RESET);
        

        //sumar 10 -10=0
        resultado=calculadora.sumar(10, -10);
        if(resultado==0)System.out.println(ColoresAnsi.ANSI_GREEN+"OK \t- 10+(-10)=0"+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error \t- 10+(-10)=0"+ColoresAnsi.ANSI_RESET);
        

        //sumar -10 -10=-20
        resultado=calculadora.sumar(-10, -10);
        if(resultado==-20)System.out.println(ColoresAnsi.ANSI_GREEN+"OK \t- -10+(-10)=-20"+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error \t- -10+(-10)=-20"+ColoresAnsi.ANSI_RESET);
        

        //sumar 200000000000000000. + 200000000000000000.       17 veces 0
        resultado=calculadora.sumar(200000000000000000., 200000000000000000.);
        if(resultado==400000000000000000.)System.out.println(ColoresAnsi.ANSI_GREEN+"OK \t- 200000000000000000.+200000000000000000.=400000000000000000."+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error \t- 200000000000000000.+200000000000000000.=400000000000000000."+ColoresAnsi.ANSI_RESET);
        

    }

    private static void separador(String nombre) {
        System.out.println();
        System.out.println("*****************************************************************");
        System.out.println("Método "+nombre);
    }
}
