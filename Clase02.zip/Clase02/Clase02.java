import javax.security.sasl.AuthorizeCallback;

public class Clase02{
    public static void main(String[] args) {
        //Lenguajes de tipado de datos fuerte   Java C C++ C# Visual Basic TypeScript
        //Lenguajes de tipado de datos debil    JavaScript Pyhton PHP

        //Tipo de datos primitivos

        //Tipo de datos enteros

        //Tipo de datos booleano    utiliza 1 bit de espacio en RAM pero ocupa 1 byte de memoria
        boolean bo=true;
        System.out.println(bo);
        bo=false;
        System.out.println(bo);

        /*
         *  boolean bo=true;
         * 
         *  boolean bo2=true;
         * 
         *  10000000
         * |--------|
         *      
         *  10000000
         * |--------|
         */

         // tipo de datos byte signed             1 byte
         byte by=100;
         System.out.println(by);

         by=127;
         System.out.println(by);

         by=-128;
         System.out.println(by);

         //by=128; //Error overfloat
        

        /*
         *   binario unsigned       decimal
         *   00000000                   0
         *   00000001                   1
         *   00000010                   2
         *   00000011                   3
         *   00000100                   4
         *   10000010                 130
         *   10000000                 128
         *   11111111                 255
         *  |--------|
         * 
         *      byte unsigned
         * 
         *      |---------------|
         *      0               255
         * 
         *      byte signed
         * 
         *      |-------|-------|
         *    -128      0      127
         * 
         * 
         *   binario signed       decimal
         *   00000000                   0
         *   00000001                  -1
         *   00000010                  -2
         *   00000011                  -3
         *   00000100                  -4
         *   10000001                   1
         *   10000010                   2
         *   10000011                   3
         *   10000100                   4
         *   10000000                   0
         *   11111111                 127
         *  |--------|
         */
        
        //Tipo de datos short   2 bytes signed
        short sh=-32000;
        System.out.println(sh);

        sh=32000;
        System.out.println(sh);

        //sh=36000; //error

        //Tipo de datos int 4 bytes 32 bits signes
        int in=-2000000000;
        System.out.println(in);

        in=2000000000;
        System.out.println(in);

        //Tipo de datos long 8 bytes 64 bits signed
        long lo=3000000000L;
        lo=2L;

        //Tipo de datos char unsigned   2 bytes   (Unicode)
        char ch=65;
        System.out.println(ch);
        ch+=32;
        System.out.println(ch);

        ch='h';
        System.out.println(ch);

        //Tipo de datos punto flotante

        //tipo de datos float 32 bits
        float fl=6.26f;
        System.out.println(fl);

        //tipo de datos double 64 bits
        double dl=6.26;
        System.out.println(dl);

        fl=1;
        dl=1;

        System.out.println(fl/3);
        System.out.println(dl/3);

        fl=10;
        dl=10;

        System.out.println(fl/3);
        System.out.println(dl/3);


        fl=100;
        dl=100;

        System.out.println(fl/3);
        System.out.println(dl/3);


        fl=1000;
        dl=1000;

        System.out.println(fl/3);
        System.out.println(dl/3);

        //Clase String
        String st="hola";
        System.out.println(st);

        /*
         *
         * JDK 10 o sup         private final byte[] value;       4 bytes
         * JDK 09 o inf         private final char[] value;       8 bytes  
         * 
         * hola
         * ----
         * 
         */
        
        String cadena="Esto es una cadena de texto!";
        //System.out.println(cadena.value[1]);
        System.out.println(cadena);

        //Recorrido de cadena
        for(int i=0; i<cadena.length();i++){
            System.out.print(cadena.charAt(i));
        }
        System.out.println();

        //Imprimir cadena en mayúsculas
        for(int i=0; i<cadena.length();i++){
            char car=cadena.charAt(i);
            if(car>=97 && car<=122) car-=32;
            System.out.print(car);
        }
        System.out.println();

        //Operador Unario
        in++;

        //Operador Binario
        in-=4;

        //Operador Ternario ?
        for(int i=0; i<cadena.length();i++){
            char car=cadena.charAt(i);
            System.out.print((char)((car>=97 && car<=122)?car-32:car));
        }
        System.out.println();

        //imprimir cadena en minúsculas
        for(int i=0; i<cadena.length(); i++){
            char car=cadena.charAt(i);
            System.out.print((char)((car>=65 && car<=90)?car+=32:car));
        }
        System.out.println();
        
        System.out.println(cadena.toUpperCase());
        System.out.println(cadena.toLowerCase());

        System.out.println(cadena.contains("hola"));
        System.out.println(cadena.contains("texto"));

        //Clase BigDecimal



    }
}
