//declaración de clase
public class Auto {
    
    //atributos
    String marca;
    String modelo;
    String color;
    int velocidad;

    //métodos
    void acelerar(){
        velocidad+=10;
    }

    void frenar(){
        velocidad-=10;
    }

}//end class
