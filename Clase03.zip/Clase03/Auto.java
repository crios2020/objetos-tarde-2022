//declaración de clase
public class Auto {
    
    //atributos
    String marca;
    String modelo;
    String color;
    int velocidad;

    //Constructor
    /**
     * Este método esta deprecado por Carlos Ríos el 12/08/2022, por ser
     * inseguro. usar en su reemplazo 
     * Auto(String marca, String modelo, String color)
     */
    @Deprecated     //Annotation JFK 5 o sup
    Auto(){} //Constructor vacio

    Auto(String marca, String modelo, String color){
        this.marca=marca;
        this.modelo=modelo;
        this.color=color;
    }

    //métodos
    void acelerar(){                                        //acelerar
        //velocidad+=10;
        //if(velocidad>100) velocidad=100;
        acelerar(10);
    }

    //método con parámetros de entrada
    /**
     * Método para acelerar
     * @param kilometros cantidad de kilometros a acelarar
     */
    void acelerar(int kilometros){                          //acelerarInt
        velocidad+=kilometros;
        if(velocidad>=100) velocidad=100;
    }

    void acelerar(int kilometros, boolean nitro){           //acelerarIntBoolean
        if(nitro){
            acelerar(kilometros*2);
        }else{
            acelerar(kilometros);           //Llamado de método dentro de la misma clase
        }
    }            

    void acelerar(int x, int y){                            //acelerarIntInt
    }

    void frenar(){
        velocidad-=10;
    }

    void imprimirVelocidad(){
        System.out.println(velocidad);
    }

    //método que retorna valor
    int obtenerVelocidad(){
        return velocidad;
    }

    @Override
    public String toString(){
        return this.marca+", "+this.modelo+", "+this.color+", "+this.velocidad;
    }

}//end class
