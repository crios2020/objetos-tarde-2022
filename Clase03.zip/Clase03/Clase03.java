import javax.swing.JOptionPane;

public class Clase03{
    public static void main(String[] args) {
        // https://www.youtube.com/channel/UCZbZVDAcSnsY5oDjxTV_-Dw/playlists
        /*
         * Que es una Clase? Representa idea generales del mundo real, se detectan como sustantivos.
         * una clase forma una plantilla.
         * 
         * Ejemplo de clases: Alumno - Computadora - Silla - Profesor - Curso - Aula
         * 
         * Clases en Java: Las clases en Java son objetos de la clase java.lang.Class
         * 
         * Que es un objeto? Un objeto es una instancia en particular de la clase, tiene estado
         * propio.
         * 
         * Que es un atributo?  Un atributo describe a la clase, son variables contenidas en la clase,
         * y tienen un tipo de datos asociado.
         * Clase clases definen los atributos y los objetos le ponen estado a los atributos.
         * 
         * Atributos en Java: Los atributos son objetos de la clases java.lang.reflect.Field
         * Los atributos en java se inicializan automáticamente al construir un objeto
         * Los atributos String se inicializan en null y 
         * los atributos númericos se inicializan en 0
         * 
         * Que es un método? Un método es una acción que realiza la clase. Opcionalmente puede
         * tener parámetros de entrada y salida.
         * 
         * Métodos en Java: Los métodos en java son objetos de la clases java.lang.reflect.Method
         * 
         * Parámetros de entrada: son valores enviados al método, estos valores
         * existen dentro del método como variables locales, el método toma estos
         * para realizar acciones, los párametros pertenecen a un tipo de datos 
         * asociado.
         * 
         * Valor de retorno: Es el valor retornado luego de la ejecución de un
         *  método, sino retorna valor el método es void. El valor de retorno 
         *  tiene un tipo de datos asociado.
         * 
         * Sobrecarga de métodos: ocurre cuando dentro de una clase dos métodos
         *  tienen el mismo nombre, pero difieren en la firma de parámetros de 
         *  entrada (cantidad o tipos de parámetros)
         * 
         * Métodos constructores: son métodos que inicializan un objeto, 
         *  no tiene devolución de valor, tienen el mismo nombre que la clase.
         *  Se ejecuta automaticamente al construir un objeto (new ).
         *  Si la clase no tiene constructor, java agrega un constructor vacio
         *  al compilar.
         * 
         * Constructores en Java: Los constructores son objetos de la clase 
         * java.lang.reflect.Constructor
         */

        System.out.println("-- auto1 --");
        Auto auto1 = new Auto();
        auto1.marca="Ford";
        auto1.modelo="Ka";
        auto1.color="Negro";

        auto1.acelerar();               //10
        auto1.acelerar();               //20
        auto1.acelerar();               //30
        auto1.frenar();                 //20
        auto1.acelerar(25);  //45 
        auto1.acelerar(10,true);    //65
        auto1.acelerar(10,false);   //75
        
        System.out.println(auto1.marca+" "+auto1.modelo+" "+auto1.color+" "+auto1.velocidad);

        //int x;
        //System.out.println(x); //Error debe ser inicializada la variable

        System.out.println("-- auto2 --");
        Auto auto2=new Auto();
        auto2.marca="Fiat";
        auto2.modelo="Idea";
        auto2.color="Gris";

        for(int a=0; a<=50; a++){
            auto2.acelerar();
        }

        System.out.println(auto2.marca+" "+auto2.modelo+" "+auto2.color+" "+auto2.velocidad);

        auto2.imprimirVelocidad();
        int velocidad=auto2.obtenerVelocidad();
        System.out.println(velocidad);
        System.out.println(auto2.obtenerVelocidad());

        //JOptionPane.showMessageDialog(null, "Hola a todos!!");
        //JOptionPane.showMessageDialog(null, "Velocidad: "+auto2.obtenerVelocidad());

        System.out.println("-- auto3 --");
        Auto auto3=new Auto("Citroen","Cactus","Blanco");
        
        //Método .toString()
        System.out.println(auto3.toString());
        System.out.println(auto3);

    }//end main
}//end class