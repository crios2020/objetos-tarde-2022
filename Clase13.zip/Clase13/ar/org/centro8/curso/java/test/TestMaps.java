package ar.org.centro8.curso.java.test;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

import javax.annotation.processing.SupportedOptions;

import ar.org.centro8.curso.java.entities.Auto;
import ar.org.centro8.curso.java.entities.Persona;

public class TestMaps {
    public static void main(String[] args) {
        //Interface Map<key,value>

        int[]vector=new int[4];
        vector[0]=5;
        System.out.println(vector[0]);

        //Map<Integer,Auto>
        Map<Integer,Auto>mapaAutos=new LinkedHashMap();
        mapaAutos.put(0, new Auto("IKA","Torino","Blanco"));
        mapaAutos.put(-20, new Auto("IKA","Estanciera","Gris"));
        mapaAutos.put(50, new Auto("Fiat","1100","Celeste"));

        System.out.println(mapaAutos.get(-20));
        System.out.println(mapaAutos.get(-30));

        //Map<String,String>
        Map<String,String>mapaSemana=null;

        //Implementación HashMap
        //mapaSemana=new HashMap();

        //Implemantación Hashtable
        //Funciona igual que HashMap, es desordenado, que no logra la 
        //misma perfomance que HashMap. se la considera legacy
        //No se recomienda su uso
        //mapaSemana=new Hashtable();

        //Implementacion=LinkedHashMap
        //mapaSemana=new LinkedHashMap();
        mapaSemana=new TreeMap();


        //app
        mapaSemana.put("lu","Lunes");
        mapaSemana.put("ma","Martes");
        mapaSemana.put("mi","Miércoles");
        mapaSemana.put("ju","Jueves");
        mapaSemana.put("vi","Viernes");
        mapaSemana.put("sa","Sábado");
        mapaSemana.put("do","Domingo");
        mapaSemana.put("xx","Lunes");
        //mapaSemana.put("lu","XXXXXXXX");
        System.out.println(mapaSemana.get("ma"));
        System.out.println("***********************");
        mapaSemana.forEach((k,v)->System.out.println(k+" "+v));
        System.out.println("***********************");
        for(String k:mapaSemana.keySet()){
            System.out.println(k+" "+mapaSemana.get(k));
        }

        //Map<Persona,Auto>
        Persona p1=new Persona("Juan","Gomez",33);
        Persona p2=new Persona("Laura","Torres",35);
        Persona p3=new Persona("Camilo","Perez",28);

        Auto a1=new Auto("IKA","Torino","Blanco");
        Auto a2=new Auto("Fiat","Toro","Verde");
        Auto a3=new Auto("Renault","Kangoo","Bordo");


        Map<Persona,Auto>mapaPA=new LinkedHashMap();
        mapaPA.put(p1, a2);
        mapaPA.put(p2, a3);
        mapaPA.put(p3, a1);

        System.out.println(mapaPA.get(p2));
        System.out.println("*****************************");
        mapaPA.forEach((p,a)->System.out.println(p+" tiene "+a));





    } 
}
