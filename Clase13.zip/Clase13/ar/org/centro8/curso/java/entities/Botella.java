package ar.org.centro8.curso.java.entities;

public class Botella {
    private String capacidad;
    private String material;
    private boolean vacio;

    public Botella(String capacidad, String material, boolean vacio) {
        this.capacidad = capacidad;
        this.material = material;
        this.vacio = vacio;
    }

    @Override
    public String toString() {
        return "Botella [capacidad=" + capacidad + ", material=" + material + ", vacio=" + vacio + "]";
    }

    public String getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(String capacidad) {
        this.capacidad = capacidad;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public boolean isVacio() {
        return vacio;
    }

    public void setVacio(boolean vacio) {
        this.vacio = vacio;
    }
    
    
}
