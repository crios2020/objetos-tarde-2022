package ar.org.centro8.curso.java.proyectofinal;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import ar.org.centro8.curso.java.proyectofinal.connector.Connector;
import ar.org.centro8.curso.java.proyectofinal.entities.Alumno;
import ar.org.centro8.curso.java.proyectofinal.entities.Curso;
import ar.org.centro8.curso.java.proyectofinal.enums.Dia;
import ar.org.centro8.curso.java.proyectofinal.enums.Turno;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_AlumnoRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_CursoRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.jdbc.AlumnoRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.jdbc.CursoRepository;
import jakarta.servlet.jsp.tagext.TryCatchFinally;

@Controller
public class WebController {

    private String mensajeCursos ="Ingrese un nuevo curso!";
    private String mensajeAlumnos ="Ingrese un nuevo alumno!";

    private I_CursoRepository cursoRepository=new CursoRepository(Connector.getConnection());
    private I_AlumnoRepository alumnoRepository=new AlumnoRepository(Connector.getConnection());

    @GetMapping("/")
    public String webMain(){
        return "index";
    }

    @GetMapping("/cursos")
    public String getWebCursos(
        @RequestParam(name="buscarTitulo", required = false, defaultValue = "")String buscarTitulo,
        Model model){
        model.addAttribute("dias", List.of(Dia.values()));
        model.addAttribute("turnos", List.of(Turno.values()));
        model.addAttribute("curso", new Curso());
        model.addAttribute("mensajeCursos", mensajeCursos);
        model.addAttribute("all", cursoRepository.getAll());
        model.addAttribute("likeTitulo", cursoRepository.getLikeTitulo(buscarTitulo));
        return "cursos";
    }

    @GetMapping("/alumnos")
    public String getWebAlumnos(
        @RequestParam(name="buscarApellido", required = false, defaultValue = "") String buscarApellido,
        Model model){
        model.addAttribute("alumno", new Alumno());
        model.addAttribute("mensajeAlumnos", mensajeAlumnos);
        model.addAttribute("cursos", cursoRepository.getAll());
        model.addAttribute("likeApellido", alumnoRepository.getLikeApellido(buscarApellido));
        return "alumnos";
    }

    @PostMapping("/saveCurso")
	public String saveCurso(@ModelAttribute Curso curso){
		//System.out.println("*************************************************************************");
		//System.out.println(curso);
		//System.out.println("*************************************************************************");
		try{
			cursoRepository.save(curso);
			mensajeCursos="Se ingreso un nuevo curso id: "+curso.getId();
		}catch(Exception e){
			mensajeCursos="Ocurrio un error!";
		}
		return "redirect:cursos";
	}
    
    @PostMapping("/saveAlumno")
    public String saveAlumno(@ModelAttribute Alumno alumno){
        System.out.println("*************************************************************************");
		System.out.println(alumno);
		System.out.println("*************************************************************************");
		
        try{
			alumnoRepository.save(alumno);
			mensajeAlumnos="Se ingreso un nuevo alumno id: "+alumno.getId();
		}catch(Exception e){
			mensajeAlumnos="Ocurrio un error!";
		}
        return "redirect:alumnos";
    }
}
