package ar.org.centro8.curso.java.excepciones;

public class Clase10 {
    public static void main(String[] args) {
        System.out.println("Clase 10");

        //System.out.println(10/0);
        //System.out.println("El programa no termina bien!!!");

        /*
         * Estructura Try Catch Finally
         * 
         * try{                                 //Obligatorio
         *      //Colocar aca las sentencias que pueden 
         *      //      arrojar una Exception(Error)
         *      //Estas sentencias tienen más costo de hardware.
         *      //Si se puede ejecutar exitosamente, el bloque termina 
         *      //normalmente.
         *      //Si hay un fallo el bloque no termina y lanza un Exception
         *      
         * } catch(Exception e){                //Obligatorio
         *      //Este bloque se ejecuta en caso de tener una Exception
         *      //Se recibe como parámetro un objeto del tipo Exception
         *      
         * } finally {                          //Opcional
         *      //Este bloque se ejecuta siempre.
         *      //Las variables declaradas en try o en catch estan fuera de 
         *      //      scope(alcance)
         * }
         * 
         * // El programa termina normalmente
         */

        try {
            System.out.println(10/1);
            int nro=Integer.parseInt("22x");
            System.out.println("Esta sentencia no se ejecuta!");
        } catch (Exception e) {
            System.out.println("Ocurrio un error!");
            System.out.println(e);
        } finally {
            System.out.println("El programa termina normalmente!!!");
        }
        


    }
}
