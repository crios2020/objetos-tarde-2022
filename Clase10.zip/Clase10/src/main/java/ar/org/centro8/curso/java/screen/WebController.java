package ar.org.centro8.curso.java.screen;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class WebController {
    
    @GetMapping("/")
    public String webMain(Model model){
        model.addAttribute("ahora", Ahora.getAhora());
        model.addAttribute("cafe", Cafe.getCafe());
        model.addAttribute("usuario", Usuario.getUsuario());
        model.addAttribute("sistema", Sistema.getSistema());
        return "main";
    }
}
