import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Clase09 {
    public static void main(String... args) {
        
        //varargs (argumentos variables)  JDK 5 o sup.
        String[] semana={"Lunes","Martes","Miércoles","Jueves","Viernes"};
        metodo1(semana);
        metodo2(semana);

        //metodo1("Primavera","Verano","Otoño","Invierno");
        metodo2("Primavera","Verano","Otoño","Invierno");

        //Tipo de datos var JDK 9
        var var1=2;                     //int
        var1=90;
        //var1=2.5; //error
        var var2=4l;                    //long
        var var3=2.4;                   //double
        var var4=2.4d;                  //double
        var var5=2.4f;                  //float
        var var6=true;                  //boolean
        var var7='a';                   //char
        var var8="a";                   //String

        metodo(2);                      //int
        metodo(2l);                     //long
        metodo(4.5);                    //double
        metodo(4.6d);                   //double
        metodo(4.5f);                   //float
        metodo(true);                   //boolean
        metodo('f');                    //char
        metodo("f");                    //String

        //Clase System
        //La clase System, representa al entorno de ejecución
        //de la maquina virtual.


        //Diccionario de configuración getProperties()
        //no varia al cambiar de SO
        System.out.println(System.getProperties());
        System.out.println(System.getProperty("os.name"));
        System.out.println(System.getProperty("os.version"));
        System.out.println(System.getProperty("os.arch"));
        System.out.println(System.getProperty("user.name"));
        System.out.println(System.getProperty("user.country"));
        System.out.println(System.getProperty("user.home"));
        System.out.println(System.getProperty("user.language"));
        System.out.println(System.getProperty("java.version"));

        //Diccionadio de configuración getEnv()
        //Varia al cambiar de SO o versión JDK
        System.out.println(System.getenv());
        System.out.println(System.getenv("HOME"));

        //método .exit()        // return 0 OK
        //System.exit(0);
        //System.out.println("Esta linea no se ejecuta!");

        // Atributos out, err, in
        //out representa el stream de salida a consola sincronico
        System.out.println("Hola a todos!!!! Mensaje 01");
        System.out.println("Hola a todos!!!! Mensaje 02");
        System.out.println("Hola a todos!!!! Mensaje 03");
        System.out.println("Hola a todos!!!! Mensaje 04");
        System.out.println("Hola a todos!!!! Mensaje 05");
        System.out.println("Hola a todos!!!! Mensaje 06");
        System.out.println("Hola a todos!!!! Mensaje 07");
        System.out.println("Hola a todos!!!! Mensaje 08");
        System.out.println("Hola a todos!!!! Mensaje 09");
        System.out.println("Hola a todos!!!! Mensaje 10");
        System.out.println("Hola a todos!!!! Mensaje 11");
        System.out.println("Hola a todos!!!! Mensaje 12");
        System.out.println("Hola a todos!!!! Mensaje 13");
        System.out.println("Hola a todos!!!! Mensaje 14");
        System.out.println("Hola a todos!!!! Mensaje 15");
        System.out.println("Hola a todos!!!! Mensaje 16");
        System.out.println("Hola a todos!!!! Mensaje 17");
        System.out.println("Hola a todos!!!! Mensaje 18");
        System.out.println("Hola a todos!!!! Mensaje 19");
        System.out.println("Hola a todos!!!! Mensaje 20");
        System.out.println("Hola a todos!!!! Mensaje 01");
        System.out.println("Hola a todos!!!! Mensaje 02");
        System.out.println("Hola a todos!!!! Mensaje 03");
        System.out.println("Hola a todos!!!! Mensaje 04");
        System.out.println("Hola a todos!!!! Mensaje 05");
        System.out.println("Hola a todos!!!! Mensaje 06");
        System.out.println("Hola a todos!!!! Mensaje 07");
        System.out.println("Hola a todos!!!! Mensaje 08");
        System.out.println("Hola a todos!!!! Mensaje 09");
        System.out.println("Hola a todos!!!! Mensaje 10");
        System.out.println("Hola a todos!!!! Mensaje 11");
        System.out.println("Hola a todos!!!! Mensaje 12");
        System.out.println("Hola a todos!!!! Mensaje 13");
        System.out.println("Hola a todos!!!! Mensaje 14");
        System.out.println("Hola a todos!!!! Mensaje 15");
        System.out.println("Hola a todos!!!! Mensaje 16");
        System.out.println("Hola a todos!!!! Mensaje 17");
        System.out.println("Hola a todos!!!! Mensaje 18");
        System.out.println("Hola a todos!!!! Mensaje 19");
        System.out.println("Hola a todos!!!! Mensaje 20");
        System.out.println("Hola a todos!!!! Mensaje 01");
        System.out.println("Hola a todos!!!! Mensaje 02");
        System.out.println("Hola a todos!!!! Mensaje 03");
        System.out.println("Hola a todos!!!! Mensaje 04");
        System.out.println("Hola a todos!!!! Mensaje 05");
        System.out.println("Hola a todos!!!! Mensaje 06");
        System.out.println("Hola a todos!!!! Mensaje 07");
        System.out.println("Hola a todos!!!! Mensaje 08");
        System.out.println("Hola a todos!!!! Mensaje 09");
        System.out.println("Hola a todos!!!! Mensaje 10");
        System.out.println("Hola a todos!!!! Mensaje 11");
        System.out.println("Hola a todos!!!! Mensaje 12");
        System.out.println("Hola a todos!!!! Mensaje 13");
        System.out.println("Hola a todos!!!! Mensaje 14");
        System.out.println("Hola a todos!!!! Mensaje 15");
        System.out.println("Hola a todos!!!! Mensaje 16");
        System.out.println("Hola a todos!!!! Mensaje 17");
        System.out.println("Hola a todos!!!! Mensaje 18");
        System.out.println("Hola a todos!!!! Mensaje 19");
        System.out.println("Hola a todos!!!! Mensaje 20");
        System.out.println("Hola a todos!!!! Mensaje 01");
        System.out.println("Hola a todos!!!! Mensaje 02");
        System.out.println("Hola a todos!!!! Mensaje 03");
        System.out.println("Hola a todos!!!! Mensaje 04");
        System.out.println("Hola a todos!!!! Mensaje 05");
        System.out.println("Hola a todos!!!! Mensaje 06");
        System.out.println("Hola a todos!!!! Mensaje 07");
        System.out.println("Hola a todos!!!! Mensaje 08");
        System.out.println("Hola a todos!!!! Mensaje 09");
        System.out.println("Hola a todos!!!! Mensaje 10");
        System.out.println("Hola a todos!!!! Mensaje 11");
        System.out.println("Hola a todos!!!! Mensaje 12");
        System.out.println("Hola a todos!!!! Mensaje 13");
        System.out.println("Hola a todos!!!! Mensaje 14");
        System.out.println("Hola a todos!!!! Mensaje 15");
        System.out.println("Hola a todos!!!! Mensaje 16");
        System.out.println("Hola a todos!!!! Mensaje 17");
        System.out.println("Hola a todos!!!! Mensaje 18");
        System.out.println("Hola a todos!!!! Mensaje 19");
        System.out.println("Hola a todos!!!! Mensaje 20");
        System.out.println("Hola a todos!!!! Mensaje 01");
        System.out.println("Hola a todos!!!! Mensaje 02");
        System.out.println("Hola a todos!!!! Mensaje 03");
        System.out.println("Hola a todos!!!! Mensaje 04");
        System.out.println("Hola a todos!!!! Mensaje 05");
        System.out.println("Hola a todos!!!! Mensaje 06");
        System.out.println("Hola a todos!!!! Mensaje 07");
        System.out.println("Hola a todos!!!! Mensaje 08");
        System.out.println("Hola a todos!!!! Mensaje 09");
        System.out.println("Hola a todos!!!! Mensaje 10");
        System.out.println("Hola a todos!!!! Mensaje 11");
        System.out.println("Hola a todos!!!! Mensaje 12");
        System.out.println("Hola a todos!!!! Mensaje 13");
        System.out.println("Hola a todos!!!! Mensaje 14");
        System.out.println("Hola a todos!!!! Mensaje 15");
        System.out.println("Hola a todos!!!! Mensaje 16");
        System.out.println("Hola a todos!!!! Mensaje 17");
        System.out.println("Hola a todos!!!! Mensaje 18");
        System.out.println("Hola a todos!!!! Mensaje 19");
        System.out.println("Hola a todos!!!! Mensaje 20");
        System.out.println("Hola a todos!!!! Mensaje 01");
        System.out.println("Hola a todos!!!! Mensaje 02");
        System.out.println("Hola a todos!!!! Mensaje 03");
        System.out.println("Hola a todos!!!! Mensaje 04");
        System.out.println("Hola a todos!!!! Mensaje 05");
        System.out.println("Hola a todos!!!! Mensaje 06");
        System.out.println("Hola a todos!!!! Mensaje 07");
        System.out.println("Hola a todos!!!! Mensaje 08");
        System.out.println("Hola a todos!!!! Mensaje 09");
        System.out.println("Hola a todos!!!! Mensaje 10");
        System.out.println("Hola a todos!!!! Mensaje 11");
        System.out.println("Hola a todos!!!! Mensaje 12");
        System.out.println("Hola a todos!!!! Mensaje 13");
        System.out.println("Hola a todos!!!! Mensaje 14");
        System.out.println("Hola a todos!!!! Mensaje 15");
        System.out.println("Hola a todos!!!! Mensaje 16");
        System.out.println("Hola a todos!!!! Mensaje 17");
        System.out.println("Hola a todos!!!! Mensaje 18");
        System.out.println("Hola a todos!!!! Mensaje 19");
        System.out.println("Hola a todos!!!! Mensaje 20");

        //atributo .err representa el stream de salida asincronico
        System.err.println("Ocurrio un error!");

        //atributo .in representa el stream de ingreso por consola sincronico
        //System.out.println("Ingrese su nombre: ");
        //String nombre=new Scanner(System.in).nextLine();

        //Clase String
        String cadena="Esto es una cadena de texto!";
        
        //metodo .contains()
        System.out.println(cadena.contains("de"));

        //metodo startsWith() endsWith()
        System.out.println(cadena.startsWith("Esto"));
        System.out.println(cadena.endsWith("Chau"));

        //substring()
        System.out.println(cadena.substring(10));
        System.out.println(cadena.substring(10, 15));
        
        //charAt()
        System.out.println(cadena.charAt(10));

        //trim()
        System.out.println("   HOLA  HOLA   ".trim());

        //indexOf()
        System.out.println(cadena.indexOf("a"));

        //toLowerCase() //toUpperCase()
        System.out.println(cadena.toLowerCase());
        System.out.println(cadena.toUpperCase());

        //equals equalsIgnoreCase
        String texto="HOLA";
        System.out.println(texto.equals("hola"));
        System.out.println(texto.equalsIgnoreCase("hola"));

        //split()
        System.out.println(System.getProperties());
        String[] propiedades=System
                                .getProperties()
                                .toString()
                                .split(",");
        for(int a=0; a<propiedades.length; a++){
            System.out.println(propiedades[a]);
        }


        //TODO Api Reflect

    }

    public static void metodo1(String[] args){
        for(int a=0;a<args.length; a++){
            System.out.println(args[a]);
        }
    }

    //Solo debe existir un argmento del tipo varargs, y debe ser el ultimo parámetro
    public static void metodo2(String... args){
        for(int a=0;a<args.length; a++){
            System.out.println(args[a]);
        }
    }

    public static void metodo(int x){
        System.out.println("int");
    }

    public static void metodo(long x){
        System.out.println("long");
    }

    public static void metodo(float x){
        System.out.println("float");
    }

    public static void metodo(double x){
        System.out.println("double");
    }

    public static void metodo(boolean x){
        System.out.println("boolean");
    }

    public static void metodo(char x){
        System.out.println("char");
    }

    public static void metodo(String x){
        System.out.println("String");
    }
}