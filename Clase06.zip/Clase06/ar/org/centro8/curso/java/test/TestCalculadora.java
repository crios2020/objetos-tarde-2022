package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.utils.Calculadora;
import ar.org.centro8.curso.java.utils.ColoresAnsi;

public class TestCalculadora {

    private static final Calculadora calculadora=new Calculadora();
    public static void main(String[] args) {
        
        sumar();

        restar();

        multiplicar();

        dividir();

    }

    private static void dividir() {
        //TODO Test dividir
        System.out.println("Método dividir");
    }

    private static void multiplicar() {
        //TODO Test multiplicar
        System.out.println("Método multiplicar");
    }

    private static void restar() {
        //TODO Test restar
        System.out.println("Método restar");
    }

    private static void sumar() {
        //TODO Test sumar
        System.out.println("Método sumar");
        double resultado;
        
        //sumar 0+0=0
        resultado=calculadora.sumar(0, 0);
        if(resultado==0)System.out.println(ColoresAnsi.ANSI_GREEN+"OK - 0+0=0"+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error - 0+0=0"+ColoresAnsi.ANSI_RESET);
        
        //sumar 2+2=4
        resultado=calculadora.sumar(2, 2);
        if(resultado==4)System.out.println(ColoresAnsi.ANSI_GREEN+"OK - 2+2=4"+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error - 2+2=4"+ColoresAnsi.ANSI_RESET);
        
        //sumar 33+72=105
        resultado=calculadora.sumar(33, 72);
        if(resultado==105)System.out.println(ColoresAnsi.ANSI_GREEN+"OK - 33+72=105"+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error - 33+72=105"+ColoresAnsi.ANSI_RESET);
        

        //sumar 10 -10=0
        resultado=calculadora.sumar(10, -10);
        if(resultado==0)System.out.println(ColoresAnsi.ANSI_GREEN+"OK - 10+(-10)=0"+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error - 10+(-10)=0"+ColoresAnsi.ANSI_RESET);
        

        //sumar -10 -10=-20
        resultado=calculadora.sumar(-10, -10);
        if(resultado==-20)System.out.println(ColoresAnsi.ANSI_GREEN+"OK - -10+(-10)=-20"+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error - -10+(-10)=-20"+ColoresAnsi.ANSI_RESET);
        

        //sumar 200000000000000000. + 200000000000000000.       17 veces 0
        resultado=calculadora.sumar(200000000000000000., 200000000000000000.);
        if(resultado==400000000000000000.)System.out.println(ColoresAnsi.ANSI_GREEN+"OK - 200000000000000000.+200000000000000000.=400000000000000000."+ColoresAnsi.ANSI_RESET);
        else            System.out.println(ColoresAnsi.ANSI_RED+"Error - 200000000000000000.+200000000000000000.=400000000000000000."+ColoresAnsi.ANSI_RESET);
        

    }
}
