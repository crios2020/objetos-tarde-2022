package ar.org.centro8.curso.java.test;

public class TestHumano {
    public static void main(String[] args) {
        
    }
}
/*
//composición no segura
class CabezaHumano{}
class Humano{
    CabezaHumano cabeza=new CabezaHumano();
}
class Perro{
    CabezaHumano cabezaHumano=new CabezaHumano();
}
*/

//El humano esta compuesto por una cabeza
//Relación de composición fuerte y acoplada
class Humano{
    //Local Inner Class
    private class CabezaHumano{}
}

class Perro{
    //CabezaHumano cabezaHumano=new CabezaHumano();
}

class Celular{}

//Alumno que tiene un celular, hay una relación en el tiempo
//Relación de composición simple
class Alumno{

    Celular celular;

    void usar(Computadora computadora){
        System.out.println("El alumno usa la computadora");
    }
}

class Amigo{
    Celular celular;
}

//El alumno usa una computadora
//Relación debil y de cohesión
class Computadora{
    //computadora del colegio
}
