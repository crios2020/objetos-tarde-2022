package ar.org.centro8.curso.java.utils;

public class Calculadora {

    /**
     * Suma los dos números ingresados en los parámetros de entrada.
     * @param nro1  número 1
     * @param nro2  número 2
     * @return  resultado de la operación
     */
    public double sumar(double nro1, double nro2) {
        //TODO sumar los párametros
        return 0;
    }

    /**
     * Resta los dos números ingresados en los parámetros de entrada.
     * @param nro1  número 1
     * @param nro2  número 2
     * @return  resultado de la operación
     */
    public double restar(double nro1, double nro2) {
        //TODO restar los párametros
        return 0;
    }

    /**
     * Multiplica los dos números ingresados en los parámetros de entrada.
     * @param nro1  número 1
     * @param nro2  número 2
     * @return  resultado de la operación
     */
    public double multiplicar(double nro1, double nro2) {
        //TODO multiplicar los párametros
        return 0;
    }

    /**
     * Divide los dos números ingresados en los parámetros de entrada.
     * En caso de división /0 imprime el cartel ArithmeticException
     * @param nro1  número 1
     * @param nro2  número 2
     * @return  resultado de la operación
     */
    public double dividir(double nro1, double nro2) {
        //TODO dividir los párametros, contemplar la div /0
        return 0;
    }
}
