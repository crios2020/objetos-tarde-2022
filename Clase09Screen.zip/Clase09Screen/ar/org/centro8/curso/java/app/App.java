package ar.org.centro8.curso.java.app;

import ar.org.centro8.curso.java.utils.Ahora;
import ar.org.centro8.curso.java.utils.Cafe;
import ar.org.centro8.curso.java.utils.Colores;
import ar.org.centro8.curso.java.utils.Gato;
import ar.org.centro8.curso.java.utils.Sistema;

public class App {
    public static void main(String[] args) {
        System.out.println(Colores.GREEN);
        System.out.println(Gato.getGato());
        System.out.println();
        System.out.println(Colores.RED_BOLD);
        System.out.println(Cafe.getCafe());
        System.out.println();
        System.out.println(Sistema.getSistema());
        System.out.println();
        System.out.println(Ahora.getAhora());
        System.out.println();
        System.out.println(Colores.RESET);
    }
}
