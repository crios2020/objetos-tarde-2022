package ar.org.centro8.curso.java.utils;
import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;

public class Ahora{
    public static void main(String[] args) {
        System.out.println(getAhora());
    }

    public static String getAhora(){

        //Class Date JDK 1.0
        //Date date=new Date();
        //System.out.println(date);

        //Class Calendar JDK 1.1
        Calendar cal=Calendar.getInstance();
        //System.out.println(cal);
        //System.out.println(cal.getTime());
        //System.out.println(cal.getTimeZone().getID());

        //Class LocalDate LocalTime LocalDateTime JDK 8
        LocalDateTime ldt=LocalDateTime.now();
        //System.out.println(ldt);

        String zona=cal.getTimeZone().getID();
        int anio=ldt.getYear();
        int mes=ldt.getMonthValue();
        int dia=ldt.getDayOfMonth();
        int diaSem=ldt.getDayOfWeek().getValue();
        int hora=ldt.getHour();
        int minuto=ldt.getMinute();

        String nombreMes="";

        if(mes==1) nombreMes="Enero";
        if(mes==2) nombreMes="Febrero";
        if(mes==3) nombreMes="Marzo";
        if(mes==4) nombreMes="Abril";
        if(mes==5) nombreMes="Mayo";
        if(mes==6) nombreMes="Junio";
        if(mes==7) nombreMes="Julio";
        if(mes==8) nombreMes="Agosto";
        if(mes==9) nombreMes="Septiembre";
        if(mes==10) nombreMes="Octubre";
        if(mes==11) nombreMes="Noviembre";
        if(mes==12) nombreMes="Diciembre";

        String nombreDia="";

        if(diaSem==1) nombreDia="Lunes";
        if(diaSem==2) nombreDia="Martes";
        if(diaSem==3) nombreDia="Miércoles";
        if(diaSem==4) nombreDia="Jueves";
        if(diaSem==5) nombreDia="Viernes";
        if(diaSem==6) nombreDia="Sábado";
        if(diaSem==7) nombreDia="Domingo";

        return "Hoy es "+nombreDia+" "+dia+" de "+nombreMes+" de "+anio
                +" "+hora+":"+minuto+" hs\n"+zona;
    }
}