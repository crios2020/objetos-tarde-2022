package ar.org.centro8.curso.java.utils.files;

import java.io.File;
import ar.org.centro8.curso.java.interfaces.I_File;

public class FileText implements I_File,Cloneable{
    private File file;

    @Override
    public String getText() {
        return "Contenido de Archivo de texto!";
    }

    @Override
    public void setText(String text) {
        System.out.println("Escribiendo Archivo de texto!");
    }
    
}
