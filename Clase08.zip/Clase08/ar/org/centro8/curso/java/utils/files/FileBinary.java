package ar.org.centro8.curso.java.utils.files;

import java.io.FileInputStream;

import ar.org.centro8.curso.java.interfaces.I_File;

public class FileBinary implements I_File{

    private FileInputStream in;

    @Override
    public String getText() {
        return "Contenido de Archivo Binario!";
    }

    @Override
    public void setText(String text) {
        System.out.println("Escribiendo Archivo Binario!");
    }
    
}
