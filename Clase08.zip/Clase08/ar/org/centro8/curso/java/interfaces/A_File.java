package ar.org.centro8.curso.java.interfaces;

import java.io.File;

public abstract class A_File {

    //Teconología de Archivos de texto
    private File file;

    public A_File(File file) {
        this.file = file;
    }

    /**
     * La java Doc es heredada.
     * Este método sirve para escribir en una archivo!
     * @param text texto a escribir.
     */
    public abstract void setText(String text);
    
    /**
     * @return retorna el String con el contenido del archivo
     */
    public abstract String getText();

    //Interfaces en Java 8 o sup
    //Métodos default: tiene implementación, tienen código
    public void info(){
        System.out.println("Interface I_File");
    }
}
