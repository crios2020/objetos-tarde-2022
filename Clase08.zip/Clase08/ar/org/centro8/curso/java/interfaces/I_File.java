package ar.org.centro8.curso.java.interfaces;

public interface I_File {

    /*
     * - Una Interface solo tiene miembros publicos
     * - Sus métodos son abstractos
     * - No hay constructores
     * - No hay atributos de objetos
     * - Puede existir constantes o atritutos estaticos.
     * - Una clase puede implementar muchas interfaces.
     * - Las clases que implementen la interface, deben implementar 
     *          los métodos abstractos.
     */

    /**
     * La java Doc es heredada.
     * Este método sirve para escribir en una archivo!
     * @param text texto a escribir.
     */
    void setText(String text);
    
    /**
     * @return retorna el String con el contenido del archivo
     */
    String getText();

    //Interfaces en Java 8 o sup
    //Métodos default: tiene implementación, tienen código
    default void info(){
        System.out.println("Interface I_File");
    }
}
