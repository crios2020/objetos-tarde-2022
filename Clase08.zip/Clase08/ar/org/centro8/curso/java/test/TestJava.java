package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.Auto;

public class TestJava {
    public static void main(String[] args) {

        Auto auto1=new Auto("Fiat","Toro","Rojo");
        Auto auto2=auto1;
        Auto auto3=new Auto(auto1.getMarca(),auto1.getModelo(),auto1.getColor());
        Auto auto4=new Auto("VW","Gol","Blando");
        String texto="Hola";
        String texto2="Hola";

        //HashCode
        System.out.println("auto1.hashCode(): "+auto1.hashCode());
        System.out.println("auto2.hashCode(): "+auto2.hashCode());
        System.out.println("auto3.hashCode(): "+auto3.hashCode());
        System.out.println("auto4.hashCode(): "+auto4.hashCode());
        System.out.println("texto.hashCode(): "+texto.hashCode());
        System.out.println("texto2.hashCode(): "+texto.hashCode());

        // Equals
        System.out.println("auto1.equals(auto1): "+auto1.equals(auto1));
        System.out.println("auto1.equals(auto2): "+auto1.equals(auto2));
        System.out.println("auto1.equals(auto3): "+auto1.equals(auto3));
        System.out.println("auto1.equals(auto4): "+auto1.equals(auto4));
        System.out.println("auto1.equals(texto): "+auto1.equals(texto));
        System.out.println("texto.equals(texto2): "+texto.equals(texto2));


        //Static
        //un miembro static pertenece a la clase y no al objeto.
        //un miembro static puede usarse sin generar un objeto de la clase.

        System.out.println("-- static --");

        Auto.acelerar();

        auto1.acelerar();                                   //20
        auto1.acelerar();                                   //30
        System.out.println(auto1);
        System.out.println(auto1.getVelocidad());           //30

        auto2.acelerar();
        System.out.println(auto2);
        System.out.println(auto2.getVelocidad());           //40
        System.out.println(auto2.getVelocidad());           //40
        System.out.println(Auto.getVelocidad());            //40

        //TODO varargs

        //TODO Clase String

        //TODO Api Reflect

    }
}
