package ar.org.centro8.curso.java.test;

public class Rectangulo {
    public int calcularPerimetro(int lado1, int lado2){
        return (lado1+lado2)*2;
    }
}
