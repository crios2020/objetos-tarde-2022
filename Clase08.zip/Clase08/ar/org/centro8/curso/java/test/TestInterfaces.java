package ar.org.centro8.curso.java.test;

import java.util.Scanner;

import ar.org.centro8.curso.java.interfaces.I_File;
import ar.org.centro8.curso.java.utils.files.FileBinary;
import ar.org.centro8.curso.java.utils.files.FileText;

public class TestInterfaces {
    public static void main(String[] args) throws Exception {

        //https://www.youtube.com/watch?v=UXAltfkVCIw&list=PLMLmotKSEKYfobV2_eyZxVxc88E-27k7t
        //Video 108 a 117
        I_File file=null;

        //file=new FileText();
        //file=new FileBinary();

        System.out.print("Ingrese 'FileBinary' o 'FileText': ");
        String in=new Scanner(System.in).nextLine();

        //if(in.equals("FileText"))   file=new FileText();
        //if(in.equals("FileBinary")) file=new FileBinary();     
        
        //file=(I_File)Class.forName("ar.org.centro8.curso.java.utils.files."+in).newInstance();

        file=(I_File)Class
                    .forName("ar.org.centro8.curso.java.utils.files."+in)
                    .getConstructor()
                    .newInstance(null);
                    
        //apps
        file.setText("hola");
        System.out.println(file.getText());
        file.info();

    }
}
