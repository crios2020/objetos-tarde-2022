package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.utils.ColoresAnsi;

public class TestColoresAnsi {
    public static void main(String[] args) {
        System.out.println(ColoresAnsi.ANSI_RED+"ROJO");
        System.out.println(ColoresAnsi.ANSI_GREEN+"VERDE");
        System.out.println(ColoresAnsi.ANSI_BLUE+"AZUL");
        System.out.println(ColoresAnsi.ANSI_RESET);
    }
}
