package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.Cliente;
import ar.org.centro8.curso.java.entities.Cuenta;
import ar.org.centro8.curso.java.entities.Direccion;
import ar.org.centro8.curso.java.entities.Persona;
import ar.org.centro8.curso.java.entities.Vendedor;

public class TestDiagramaHerencia {
    public static void main(String[] args) {
        
        System.out.println("-- dir1 --");
        Direccion dir1=new Direccion("Medrano", 162, "1", "1");
        System.out.println(dir1);

        System.out.println("-- dir2 --");
        Direccion dir2=new Direccion("Belgrano",456, null, null, "Moron");
        System.out.println(dir2);

        //Persona p1=new Persona("Juan","38",dir1);
        //Error la clase persona es abstracta

        System.out.println("-- vendedor1 --");
        Vendedor vendedor1=new Vendedor(
            "Lorena", 43, dir1, 1, 250000
        );
        System.out.println(vendedor1);
        vendedor1.saludar();

        System.out.println("-- cliente1 --");
        Cliente cliente1=new Cliente(
            "Gabriel", 38, dir2, 1, new Cuenta(200,"arg$")
        );
        cliente1.getCuenta().depositar(40000);
        cliente1.setDireccion(new Direccion("Lavalle", 48, "8", "1"));
        System.out.println(cliente1);
        cliente1.saludar();




    }
}
