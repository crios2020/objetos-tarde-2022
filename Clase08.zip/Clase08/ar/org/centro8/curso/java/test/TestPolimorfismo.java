package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.Cliente;
import ar.org.centro8.curso.java.entities.Cuenta;
import ar.org.centro8.curso.java.entities.Direccion;
import ar.org.centro8.curso.java.entities.Persona;
import ar.org.centro8.curso.java.entities.Vendedor;

public class TestPolimorfismo {
    public static void main(String[] args) {
        // Polimorfismo - Poliformismo

        double y=3.3;
        int x=3;
        Object o=y;

        Persona p1=
            new Vendedor(
                "Hernan", 
                33, 
                new Direccion("lima",22,null,null), 
                1, 
                200000);
        Persona p2=
            new Cliente(
                "Jimena", 
                38, 
                new Direccion("Viel", 222, null, null), 
                1, 
                new Cuenta(1, "arg$"));

        p1.saludar();       //vendedor
        p2.saludar();       //cliente

        Vendedor v1=(Vendedor)p1;
        Vendedor v2=(p1 instanceof Vendedor)?(Vendedor)p1:null;

        System.out.println(p1.getClass());
        System.out.println(p2.getClass());
        System.out.println(p2.getClass().getName());
        System.out.println(p2.getClass().getSimpleName());
        System.out.println(p2.getClass().getSuperclass().getName());
        System.out.println(p2.getClass().getSuperclass().getSuperclass().getName());
        System.out.println(
                            p2
                                .getClass()
                                .getSuperclass()
                                .getSuperclass()
                                .getSuperclass()
        );

        String texto="hola";
        System.out.println(texto.getClass().getName());
        System.out.println(texto.getClass().getSuperclass().getName());


    }
}
