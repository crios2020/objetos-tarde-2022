package ar.org.centro8.curso.java.test;
import ar.org.centro8.curso.java.entities.Cuenta;;

//class TestVulnerabilidadCuenta extends Cuenta{
    //Error no se puede crear una clase hija de Cuenta por que es final
//}