package ar.org.centro8.curso.java.utils;

public class Calculadora {
    public double sumar         (double nro1, double nro2){ return 0; }
    public double restar        (double nro1, double nro2){ return 0; }
    public double multiplicar   (double nro1, double nro2){ return 0; }
    public double dividir       (double nro1, double nro2){ return 0; }
}
